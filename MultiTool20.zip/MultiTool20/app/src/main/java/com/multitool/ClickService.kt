package com.multitool

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class ClickService : AccessibilityService() {
    companion object { var instance: ClickService? = null }

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var dot: TextView? = null
    private lateinit var dotLp: WindowManager.LayoutParams
    private var running = false
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this; wm = getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { hide(); instance = null; return super.onUnbind(i) }

    private fun lp(g: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    fun show() {
        if (panel != null) return
        val d = TextView(this).apply { text = "◎"; textSize = 34f; setTextColor(Color.RED); setBackgroundColor(0x66FFFFFF) }
        dotLp = lp(0).apply { x = 300; y = 700 }
        d.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_MOVE) {
                dotLp.x = (ev.rawX - v.width / 2).toInt(); dotLp.y = (ev.rawY - v.height / 2).toInt()
                wm.updateViewLayout(v, dotLp)
            }
            true
        }
        val go = TextView(this).apply { text = "  ▶  "; textSize = 28f; setTextColor(Color.WHITE) }
        val x = TextView(this).apply { text = "  ✕  "; textSize = 28f; setTextColor(Color.WHITE) }
        val p = LinearLayout(this).apply { setBackgroundColor(0xCC000000.toInt()); addView(go); addView(x) }
        go.setOnClickListener { toggle(go) }
        x.setOnClickListener { hide() }
        wm.addView(d, dotLp); dot = d
        wm.addView(p, lp(0).apply { gravity = Gravity.TOP or Gravity.END; y = 250 }); panel = p
    }

    private fun toggle(btn: TextView) {
        running = !running
        btn.text = if (running) "  ⏸  " else "  ▶  "
        dotLp.flags = if (running) dotLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else dotLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        dot?.let { wm.updateViewLayout(it, dotLp) }
        h.removeCallbacks(tick); if (running) h.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val d = dot ?: return
            val path = Path().apply { moveTo(dotLp.x + d.width / 2f, dotLp.y + d.height / 2f) }
            dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build(), null, null)
            val ms = getSharedPreferences("mt", MODE_PRIVATE).getInt("interval", 200)
            h.postDelayed(this, ms.toLong())
        }
    }

    fun hide() {
        running = false; h.removeCallbacks(tick)
        panel?.let { wm.removeView(it) }; dot?.let { wm.removeView(it) }
        panel = null; dot = null
    }
}
