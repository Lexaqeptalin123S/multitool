package com.multitool

import android.app.Activity
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.security.SecureRandom
import java.util.Locale
import kotlin.random.Random

/** Простой калькулятор выражений: + - * / скобки */
class P(private val s: String) {
    private var i = 0
    fun e(): Double { var v = t(); while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = t(); v = if (o == '+') v + r else v - r }; return v }
    private fun t(): Double { var v = f(); while (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = f(); v = if (o == '*') v * r else v / r }; return v }
    private fun f(): Double {
        if (s[i] == '-') { i++; return -f() }
        if (s[i] == '(') { i++; val v = e(); i++; return v }
        val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        return s.substring(st, i).toDouble()
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var tick: Runnable? = null
    private var timer: CountDownTimer? = null
    private var home = true
    private var torch = false

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    private fun Double.f(): String =
        if (this == Math.floor(this) && Math.abs(this) < 1e15) toLong().toString()
        else String.format(Locale.US, "%.4f", this).trimEnd('0').trimEnd('.')

    override fun onCreate(b: Bundle?) { super.onCreate(b); menu() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (home) super.onBackPressed() else menu() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun tv(t: String, s: Float = 16f) = TextView(this).apply { text = t; textSize = s; setPadding(0, 8.dp(), 0, 8.dp()) }
    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
    private fun edit(hint: String, num: Boolean) = EditText(this).apply {
        this.hint = hint
        inputType = if (num) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        else InputType.TYPE_CLASS_TEXT
    }

    private fun page(title: String, root: Boolean = false, build: LinearLayout.() -> Unit) {
        tick?.let { h.removeCallbacks(it) }; timer?.cancel(); home = root
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 48.dp(), 16.dp(), 24.dp()) }
        col.addView(tv(title, 24f)); col.build()
        setContentView(ScrollView(this).apply { addView(col) })
    }

    /** Универсальная форма: поля -> результат */
    private fun form(name: String, hints: List<String>, num: Boolean = true, calc: (List<String>) -> String) = page(name) {
        val es = hints.map { edit(it, num).also { e -> addView(e) } }
        val out = tv("", 18f)
        addView(btn("Посчитать") {
            out.text = try { calc(es.map { it.text.toString().trim().let { s -> if (num) s.replace(',', '.') else s } }) }
            catch (e: Exception) { "Ошибка ввода" }
        })
        addView(out)
    }

    private fun menu() = page("Мульти-инструмент 20 в 1", true) {
        val tools = listOf<Pair<String, () -> Unit>>(
            "Автокликер" to { clicker() },
            "Калькулятор" to { form("Калькулятор", listOf("Выражение, напр. (2+3)*4"), false) { P(it[0].replace(" ", "").replace(',', '.')).e().f() } },
            "Фонарик" to { flash() },
            "Секундомер" to { stopwatch() },
            "Таймер" to { timerTool() },
            "Счётчик" to { counter() },
            "Монетка" to { rollPage("Монетка", "Бросить") { if (Random.nextBoolean()) "Орёл" else "Решка" } },
            "Кубик" to { rollPage("Кубик", "Бросить") { Random.nextInt(1, 7).toString() } },
            "Случайное число" to { form("Случайное число", listOf("От", "До")) { Random.nextLong(it[0].toLong(), it[1].toLong() + 1).toString() } },
            "Генератор паролей" to { form("Пароль", listOf("Длина")) {
                val c = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#%&*"
                val r = SecureRandom(); (1..it[0].toDouble().toInt()).map { c[r.nextInt(c.length)] }.joinToString("") } },
            "Заметки" to { notes() },
            "Длина (метры →)" to { form("Метры →", listOf("Метры")) { val m = it[0].toDouble()
                "км: ${(m / 1000).f()}\nмили: ${(m / 1609.344).f()}\nфуты: ${(m * 3.28084).f()}\nдюймы: ${(m * 39.3701).f()}" } },
            "Температура" to { form("°C →", listOf("Градусы Цельсия")) { val c = it[0].toDouble()
                "°F: ${(c * 9 / 5 + 32).f()}\nK: ${(c + 273.15).f()}" } },
            "Вес (кг →)" to { form("Килограммы →", listOf("Килограммы")) { val k = it[0].toDouble()
                "фунты: ${(k * 2.20462).f()}\nунции: ${(k * 35.274).f()}\nграммы: ${(k * 1000).f()}" } },
            "Проценты" to { form("Проценты", listOf("Число", "Процент")) { val n = it[0].toDouble(); val p = it[1].toDouble()
                "$p% от числа: ${(n * p / 100).f()}\nЧисло + $p%: ${(n * (1 + p / 100)).f()}\nЧисло − $p%: ${(n * (1 - p / 100)).f()}" } },
            "ИМТ" to { form("Индекс массы тела", listOf("Вес, кг", "Рост, см")) { val w = it[0].toDouble(); val hh = it[1].toDouble() / 100
                val b = w / (hh * hh); "ИМТ: ${String.format(Locale.US, "%.1f", b)} — " + when { b < 18.5 -> "недовес"; b < 25 -> "норма"; b < 30 -> "избыток"; else -> "ожирение" } } },
            "Чаевые / делим счёт" to { form("Чаевые", listOf("Сумма счёта", "Чаевые, %", "Человек")) { val s = it[0].toDouble(); val t = it[1].toDouble(); val n = it[2].toDouble()
                val tot = s * (1 + t / 100); "Итого: ${tot.f()}\nС каждого: ${(tot / n).f()}" } },
            "Об устройстве" to { info() },
            "Счётчик слов" to { form("Слова и символы", listOf("Вставьте текст"), false) {
                "Слов: ${it[0].split(Regex("\\s+")).count { w -> w.isNotEmpty() }}\nСимволов: ${it[0].length}" } },
            "Тест скорости кликов" to { cps() }
        )
        tools.forEachIndexed { i, (n, a) -> addView(btn("${i + 1}. $n") { a() }) }
    }

    private fun rollPage(title: String, label: String, roll: () -> String) = page(title) {
        val t = tv("—", 56f); addView(t); addView(btn(label) { t.text = roll() })
    }

    private fun counter() = page("Счётчик") {
        var n = 0; val t = tv("0", 64f); addView(t)
        addView(btn("+1") { t.text = (++n).toString() })
        addView(btn("−1") { t.text = (--n).toString() })
        addView(btn("Сброс") { n = 0; t.text = "0" })
    }

    private fun stopwatch() = page("Секундомер") {
        val t = tv("0.0 с", 48f); addView(t)
        var start = 0L; var going = false
        val r = object : Runnable { override fun run() {
            t.text = String.format(Locale.US, "%.1f с", (SystemClock.elapsedRealtime() - start) / 1000.0); h.postDelayed(this, 100) } }
        tick = r
        addView(btn("Старт / Стоп") { going = !going; if (going) { start = SystemClock.elapsedRealtime(); h.post(r) } else h.removeCallbacks(r) })
    }

    private fun timerTool() = page("Таймер") {
        val e = edit("Секунд", true); addView(e); val t = tv("", 40f); addView(t)
        addView(btn("Старт") {
            timer?.cancel()
            val s = e.text.toString().toDoubleOrNull()
            if (s != null && s > 0) timer = object : CountDownTimer((s * 1000).toLong(), 200) {
                override fun onTick(m: Long) { t.text = "${m / 1000 + 1} с" }
                override fun onFinish() { t.text = "Время вышло!"
                    getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(800, 255)) }
            }.start()
        })
    }

    private fun flash() = page("Фонарик") {
        addView(btn("Вкл / Выкл") {
            try { val cm = getSystemService(CameraManager::class.java); torch = !torch; cm.setTorchMode(cm.cameraIdList[0], torch) }
            catch (e: Exception) { toast("Вспышка недоступна") }
        })
    }

    private fun notes() = page("Заметки") {
        val p = getSharedPreferences("mt", MODE_PRIVATE)
        val e = edit("Ваша заметка", false).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 8; setText(p.getString("note", "")) }
        addView(e); addView(btn("Сохранить") { p.edit().putString("note", e.text.toString()).apply(); toast("Сохранено") })
    }

    private fun info() = page("Об устройстве") {
        val bat = getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        addView(tv("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nБатарея: $bat%", 18f))
    }

    private fun cps() = page("Тест кликов (10 с)") {
        var n = 0; var st = 0L; val t = tv("Жми!", 32f); addView(t)
        addView(btn("ЖМИ") {
            val now = SystemClock.elapsedRealtime()
            if (st == 0L || now - st > 10000) { st = now; n = 0 }
            n++; t.text = "Кликов: $n\n" + String.format(Locale.US, "%.1f", n / ((now - st + 1) / 1000.0)) + " кл/с"
        })
    }

    private fun clicker() = page("Автокликер") {
        val p = getSharedPreferences("mt", MODE_PRIVATE)
        addView(tv("1) Откройте спец. возможности и включите «Мульти 20в1».\n2) Задайте интервал и нажмите «Показать панель».\n3) Перетащите ◎ на нужную точку и нажмите ▶ на панели (✕ — закрыть).", 15f))
        val e = edit("Интервал, мс (мин. 60)", true).apply { setText(p.getInt("interval", 200).toString()) }; addView(e)
        addView(btn("Открыть спец. возможности") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        addView(btn("Показать панель") {
            val v = e.text.toString().toDoubleOrNull()?.toInt() ?: 200
            p.edit().putInt("interval", maxOf(60, v)).apply()
            val s = ClickService.instance
            if (s == null) toast("Сначала включите службу в спец. возможностях") else s.show()
        })
    }
}
