МУЛЬТИ 20в1 — как получить APK

Способ 1 (Android Studio): File > Open > папка MultiTool20 > дождаться Sync >
Build > Build App Bundle(s) / APK(s) > Build APK(s). Файл: app/build/outputs/apk/debug/app-debug.apk

Способ 2 (без ПК-установок): создайте репозиторий на GitHub, загрузите всё содержимое папки,
вкладка Actions > Build APK > Run workflow > скачайте artifact MultiTool-APK.

Автокликер: Настройки > Спец. возможности > «Мульти 20в1» > включить.
(На Android 13+ из-за установки не из Play Market: Настройки > Приложения > Мульти 20в1 > ⋮ > «Разрешить ограниченные настройки».)
